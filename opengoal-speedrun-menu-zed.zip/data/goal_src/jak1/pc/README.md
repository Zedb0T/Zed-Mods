This directory contains new source code files used for the PC port
