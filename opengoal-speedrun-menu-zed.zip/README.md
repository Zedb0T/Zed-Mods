# OpenGoal-Mod-Base
Serves as a base template for openGOAL mods that will be supported via [opengoal-mod-launcher](https://github.com/OpenGOAL-Unofficial-Mods/opengoal-mod-launcher).

- Please ensure you are not committing copyrighted material to your repo (the `.gitignore` should help prevent this). 
- Generally speaking you should only be updating certain directories/files:
  - the executable binaries (`goalc.exe`, `gk.exe`, `extractor.exe`)
  - GOAL code (`/data/goal_src`)
  - Assets specific to the PC Port (`/data/game/assets/jak1/`)
  - Decompiler config (`/data/decompiler/config`)